﻿images 폴더: Flow에 업로드할 키 이미지 35장
VIDEO_PROMPTS.md: 컷 번호별 한글·영어 영상 프롬프트
FLOW_EDIT_LIST.csv: 각 컷의 생성·편집 길이
예: images/S01-01.jpg와 S01-01 프롬프트를 함께 사용합니다.
