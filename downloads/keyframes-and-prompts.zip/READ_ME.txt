﻿images 폴더의 컷 번호와 VIDEO_PROMPTS.md의 같은 번호를 사용하세요. JPEG 35장, 한영 영상 프롬프트, 편집표가 들어 있습니다.
